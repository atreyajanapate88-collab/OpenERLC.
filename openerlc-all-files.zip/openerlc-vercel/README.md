# OpenERLC on Vercel

Static chat page (`public/index.html`) + serverless function (`api/chat.py`). No dependencies.

## Deploy
1. Put this folder in a GitHub repo (the `api`, `public` folders and `vercel.json` must be at the repo root).
2. In Vercel: Add New > Project > import the repo. Framework preset: Other. Deploy.
3. Project > Settings > Environment Variables, add:
   - `GROQ_API_KEY`  (free key from the Groq console)
   - `ERLC_SERVER_KEY`  (in-game Settings > API key; optional, enables live stats)
4. Redeploy (env vars apply to new deployments).
5. Check `https://YOUR-SITE.vercel.app/api/health` shows `"ok": true` and `"ai_key": true`.

Never put keys in the code or the page. Optional vars: `LLM_MODEL`, `LLM_BASE_URL`, `LLM_API_KEY`, `OPENERLC_RATE_PER_MIN`.
Per-IP rate limiting is in-memory per function instance, so it is only a light guard.
