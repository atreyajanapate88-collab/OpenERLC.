import json, os
from http.server import BaseHTTPRequestHandler


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        b = json.dumps({"ok": True, "live_stats": bool(os.environ.get("ERLC_SERVER_KEY")),
                        "ai_key": bool(os.environ.get("LLM_API_KEY") or os.environ.get("GROQ_API_KEY"))}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)
